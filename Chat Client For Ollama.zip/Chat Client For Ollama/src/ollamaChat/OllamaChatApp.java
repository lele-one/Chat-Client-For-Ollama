package ollamaChat;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONObject;
import org.json.JSONArray;

public class OllamaChatApp extends JFrame {
    private static final long serialVersionUID = 1L;
    private JSONArray chatHistory = new JSONArray();
    private JTextArea textArea = new JTextArea();
    private JTextArea inputBox = new JTextArea(5, 20);
    private JButton sendButton = new JButton("发送 (Send)");
    private JButton copyButton = new JButton("复制上一条 (Copy Last)");
    private JButton pauseButton = new JButton("暂停 (Pause)");
    private HttpClient client = HttpClient.newHttpClient();
    private boolean isFirstResponse = true;
    private StringBuilder lastResponse = new StringBuilder();
    private JComboBox<String> modelSelector;
    private String currentModel = "qwen2:7b";
    private boolean isPaused = false;
    private boolean isOutputComplete = true;
    private StringBuilder pausedData = new StringBuilder();

    public OllamaChatApp() {
        setTitle("Chat Client For Ollama(Alibaba qwen2:7b)");
        setSize(700, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        modelSelector = new JComboBox<>(new String[]{"Llama3:8b", "qwen2:7b", "phi3:14b", "codegemma:7b","qwen2:0.5b"});
        modelSelector.setSelectedIndex(1);
        modelSelector.addActionListener(e -> {
            currentModel = (String) modelSelector.getSelectedItem();
            updateTitle();
        });

        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        JScrollPane textScrollPane = new JScrollPane(textArea);
        textScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        textScrollPane.getVerticalScrollBar().addAdjustmentListener(e -> {
            if (!isPaused && !isOutputComplete) {
                e.getAdjustable().setValue(e.getAdjustable().getMaximum());
            }
        });

        add(textScrollPane, BorderLayout.CENTER);

        inputBox.setLineWrap(true);
        inputBox.setWrapStyleWord(true);
        JScrollPane inputScrollPane = new JScrollPane(inputBox);
        inputScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        inputScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
        buttonPanel.add(sendButton);
        buttonPanel.add(copyButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(modelSelector);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(inputScrollPane, BorderLayout.CENTER);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        sendButton.addActionListener(this::sendQuery);
        copyButton.addActionListener(e -> copyToClipboard());
        pauseButton.addActionListener(e -> togglePauseOutput());

        inputBox.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (e.isShiftDown()) {
                        inputBox.append("\n");
                    } else {
                        sendQuery(null);
                        e.consume();
                    }
                }
            }
        });
    }

    private void updateTitle() {
        switch (currentModel) {
            case "qwen2:7b":
                setTitle("Chat Client For Ollama(Alibaba qwen2:7b)");
                break;
            case "qwen2:0.5b":
                setTitle("Chat Client For Ollama(Alibaba qwen2:0.5b)");
                break;
            case "Llama3:8b":
                setTitle("Chat Client For Ollama(Meta Llama3:8b)");
                break;
            case "phi3:14b":
                setTitle("Chat Client For Ollama(Microsoft phi3:14b)");
                break;
            case "codegemma:7b":
                setTitle("Chat Client For Ollama(codegemma:7b)");
                break;
            default:
                setTitle("Ollama模型前端");
                break;
        }
    }

    private void sendQuery(ActionEvent e) {
        String userQuery = inputBox.getText().trim();
        if (!userQuery.isEmpty()) {
            if (textArea.getText().isEmpty()) {
                updateChat("me: \n" + userQuery + "\n");
            } else {
                updateChat("\n\n" + "me: \n" + userQuery + "\n");
            }
            inputBox.setText("");
            isFirstResponse = true;
            lastResponse.setLength(0);

            chatHistory.put(new JSONObject().put("role", "user").put("content", userQuery));

            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://127.0.0.1:11434/api/chat"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString("{\"model\": \"" + currentModel + "\", \"messages\": " + chatHistory.toString() + "}"))
                .build();

            isOutputComplete = false;
            client.sendAsync(request, HttpResponse.BodyHandlers.ofLines())
                .thenAccept(response -> {
                    response.body().forEach(this::processResponseLine);
                    isOutputComplete = true;
                });
        }
    }

    private void processResponseLine(String line) {
        if (isFirstResponse) {
            String modelDisplay;
            switch (currentModel) {
                case "qwen2:7b":
                    modelDisplay = "Alibaba qwen2:7b";
                    break;
                case "qwen2:0.5b":
                    modelDisplay = "Alibaba qwen2:0.5b";
                    break;
                case "Llama3:8b":
                    modelDisplay = "Meta Llama3:8b";
                    break;
                case "phi3:14b":
                    modelDisplay = "Microsoft phi3:14b";
                    break;
                case "codegemma:7b":
                    modelDisplay = "codegemma:7b";
                    break;
                default:
                    modelDisplay = currentModel;
                    break;
            }
            updateChat("\n" + modelDisplay + ": \n");
            isFirstResponse = false;
        }

        try {
            JSONObject jsonObject = new JSONObject(line);
            String content = jsonObject.getJSONObject("message").getString("content");
            if (isPaused) {
                pausedData.append(content);
            } else {
                lastResponse.append(content);
                updateChat(content);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateChat(String message) {
        SwingUtilities.invokeLater(() -> textArea.append(message));
    }

    private void copyToClipboard() {
        StringSelection stringSelection = new StringSelection(lastResponse.toString());
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
    }

    private void togglePauseOutput() {
        isPaused = !isPaused;
        if (isPaused) {
            pauseButton.setText("继续 (Resume)");
            sendButton.setEnabled(false);
        } else {
            pauseButton.setText("暂停 (Pause)");
            sendButton.setEnabled(true);
            if (pausedData.length() > 0) {
                updateChat(pausedData.toString());
                lastResponse.append(pausedData.toString());
                pausedData.setLength(0);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OllamaChatApp().setVisible(true));
    }
}